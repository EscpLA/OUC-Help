export default{
  // 开启命名空间，所有的state和Mutations 需要指定模块名才可调用
  namespaced: true,
  
  //状态
  state:{
    // 用户个人信息,先获取 内存中是否有 userInfo ，如果没有则为空对象，因为是字符串，故需要 JSON.parse 为真正的对象。
    userInfo: JSON.parse(uni.getStorageSync('userInfo') || '{}'),

    // 学生信息，存放学号、专业、年纪等
      stuInfo: JSON.parse(uni.getStorageSync('stuInfo') || '{}'),
    
    // 用户令牌，登陆后为用户唯一的凭证(字符串类型)
    token: uni.getStorageSync('token') || '',
    // 存储用户是否已经注册（输入学号等个人信息）
    isSignUp: uni.getStorageSync('isSignUp') || false,
  },
  
  // 改变方法
  mutations: {
    // 更新用户信息
    updateUserinfo(state, userInfo) {
      state.userInfo = userInfo
      this.commit('m_user/saveUserInfoToStorage')
    },
    // 把用户信息持久化存储到本地，以便自动登录。
    saveUserInfoToStorage(state) {
      uni.setStorageSync('userInfo', JSON.stringify(state.userInfo))
    },
    
    //更新token
    updateToken(state, token) {
      state.token = token
      console.log(token);
      this.commit('m_user/saveTokenToStorage')
    },
    // 将token持久化存储到本地
    saveTokenToStorage(state, token) {
      uni.setStorageSync('token', state.token)
    },
    
    // 更新用户注册状态
    updateSignUp(state, payload) {
      state.isSignUp = payload
      console.log(state.isSignUp);
      this.commit('m_user/saveSignUpToStorage')
    },
    // 把isSignUp持久化存储到本地
    saveSignUpToStorage(state) {
      uni.setStorageSync('isSignUp', state.isSignUp)
    },
    
    updateStuInfo(state, stuInfo) {
      state.stuInfo = stuInfo
      this.commit('m_user/saveStuInfoToStorage')
    },
    saveStuInfoToStorage(state) {
      uni.setStorageSync('stuInfo', JSON.stringify(state.stuInfo))
    }
  }
}